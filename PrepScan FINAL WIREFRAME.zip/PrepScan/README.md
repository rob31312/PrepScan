# PrepScan (Wireframe Version)

* Finalized wireframe version to navigate all screens that will be included in final working version.
* Plan to use ZXing (Zebra Crossing) open source libraries to handle all QRCodes/barcodes
* Plan to add SQLight for data handling.
* Plan to add ability to print.
