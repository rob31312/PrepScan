package com.prepscan.ui;

import android.os.Bundle;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.prepscan.R;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        setupTopBarWithMenu(getString(R.string.title_inventory), R.menu.menu_inventory);

// Inventory-specific actions (wireframe only)
com.google.android.material.appbar.MaterialToolbar toolbar = findViewById(R.id.topAppBar);
if (toolbar != null) {
    toolbar.setOnMenuItemClickListener(item -> {
        int id = item.getItemId();
        if (id == R.id.action_home) {
            android.content.Intent i = new android.content.Intent(this, HomeActivity.class);
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP | android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
            return true;
        } else if (id == R.id.action_snapshot_inventory) {
            android.content.SharedPreferences sp = getSharedPreferences("prepscan_wireframe", MODE_PRIVATE);
            sp.edit().putLong("inventory_snapshot_time", System.currentTimeMillis()).apply();
            Toast.makeText(this, "Wireframe: inventory snapshot saved.", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.action_print_supplies) {
            android.content.SharedPreferences sp = getSharedPreferences("prepscan_wireframe", MODE_PRIVATE);
            long t = sp.getLong("inventory_snapshot_time", 0L);
            if (t == 0L) {
                Toast.makeText(this, "Take a snapshot first.", Toast.LENGTH_SHORT).show();
            } else {
                // Wireframe: inventory diff tracking is not implemented yet.
                Toast.makeText(this, "No supplies required at this time.", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        return false;
    });
}

        RecyclerView recycler = findViewById(R.id.recyclerContainers);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        List<String> mock = new ArrayList<>();
        mock.add("FS001"); mock.add("MB001"); mock.add("EP001");
        recycler.setAdapter(new SimpleTextAdapter(mock));

        MaterialButton btn = findViewById(R.id.btnPrintContainers);
        btn.setOnClickListener(v -> Toast.makeText(this, "Wireframe: print selected", Toast.LENGTH_SHORT).show());
    }
}
