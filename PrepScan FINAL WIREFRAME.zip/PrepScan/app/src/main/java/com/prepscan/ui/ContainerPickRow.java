package com.prepscan.ui;

public class ContainerPickRow {
    public final String id;
    public final String location;

    public ContainerPickRow(String id, String location) {
        this.id = id;
        this.location = location;
    }
}
