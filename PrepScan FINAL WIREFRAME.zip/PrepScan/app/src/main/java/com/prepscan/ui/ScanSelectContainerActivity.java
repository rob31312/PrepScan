package com.prepscan.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.prepscan.R;

import java.util.ArrayList;
import java.util.List;

public class ScanSelectContainerActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_select_container);
        setupTopBar(getString(R.string.title_scan_container));

        RecyclerView recycler = findViewById(R.id.recyclerContainers);
        recycler.setLayoutManager(new LinearLayoutManager(this));

        List<ContainerPickRow> mock = new ArrayList<>();
        mock.add(new ContainerPickRow("FS001", "Pantry, Rack A, Bay 1, Shelf 2"));
        mock.add(new ContainerPickRow("MB001", "Garage, Rack B, Bay 2, Shelf 1"));
        mock.add(new ContainerPickRow("EP001", "Hall closet, Rack 1, Bay 1, Shelf 1"));
        mock.add(new ContainerPickRow("GL003", "Basement, Rack C, Bay 3, Shelf 4"));

        ContainerPickAdapter adapter = new ContainerPickAdapter(mock, row -> {
            Intent i = new Intent(this, AddContentsActivity.class);
            i.putExtra(AddContentsActivity.EXTRA_CONTAINER_ID, row.id);
            startActivity(i);
        });

        recycler.setAdapter(adapter);
    }
}
