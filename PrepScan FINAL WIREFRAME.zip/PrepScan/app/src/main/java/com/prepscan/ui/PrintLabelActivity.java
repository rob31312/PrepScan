package com.prepscan.ui;

import android.os.Bundle;
import android.widget.Toast;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.prepscan.R;

import java.util.ArrayList;
import java.util.List;

public class PrintLabelActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_print_label);
        setupTopBar(getString(R.string.title_print_label));

        RecyclerView recycler = findViewById(R.id.recyclerLabels);
        recycler.setLayoutManager(new GridLayoutManager(this, 4));

        List<Integer> cells = new ArrayList<>();
        for (int i = 1; i <= 24; i++) cells.add(i);
        recycler.setAdapter(new SimpleNumberAdapter(cells));

        MaterialButton btnPrint = findViewById(R.id.btnPrint);
        btnPrint.setOnClickListener(v -> Toast.makeText(this, "Wireframe: print", Toast.LENGTH_SHORT).show());
    }
}
