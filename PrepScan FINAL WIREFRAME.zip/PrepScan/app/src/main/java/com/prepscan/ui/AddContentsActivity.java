package com.prepscan.ui;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.prepscan.R;

import java.util.ArrayList;
import java.util.List;

public class AddContentsActivity extends BaseActivity {

    public static final String EXTRA_CONTAINER_ID = "container_id";

    private String containerId = "FS001";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contents);

        if (getIntent() != null && getIntent().hasExtra(EXTRA_CONTAINER_ID)) {
            String incoming = getIntent().getStringExtra(EXTRA_CONTAINER_ID);
            if (incoming != null && !incoming.trim().isEmpty()) {
                containerId = incoming.trim();
            }
        }

        setupTopBarWithMenu("Add Contents, " + containerId, R.menu.menu_topbar_contents);

        RecyclerView recycler = findViewById(R.id.recyclerContents);
        recycler.setLayoutManager(new LinearLayoutManager(this));

        List<ContentRow> mock = new ArrayList<>();
        mock.add(new ContentRow("Bottled water, 16.9 oz", 6));
        mock.add(new ContentRow("First aid kit", 1));
        mock.add(new ContentRow("Flashlight", 2));
        mock.add(new ContentRow("AA batteries", 12));

        ContentsAdapter adapter = new ContentsAdapter(mock, () ->
                startActivity(new android.content.Intent(this, EditItemActivity.class))
        );
        recycler.setAdapter(adapter);
    }

    @Override
    protected boolean onContainerOptionsSelected() {
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        View sheet = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_container_options, null, false);

        sheet.findViewById(R.id.btnEditLocation).setOnClickListener(v -> {
            dialog.dismiss();
            new AlertDialog.Builder(this)
                    .setTitle("Edit location, " + containerId)
                    .setView(LayoutInflater.from(this).inflate(R.layout.dialog_edit_location, null, false))
                    .setPositiveButton("Done", (d, which) -> Toast.makeText(this, "Wireframe: location would autosave", Toast.LENGTH_SHORT).show())
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        sheet.findViewById(R.id.btnDeleteContainer).setOnClickListener(v -> {
            dialog.dismiss();
            new AlertDialog.Builder(this)
                    .setTitle("Delete container?")
                    .setMessage("Delete " + containerId + " and its contents?")
                    .setPositiveButton("Delete", (d, which) -> {
                        Toast.makeText(this, "Wireframe: container deleted: " + containerId, Toast.LENGTH_SHORT).show();
                        startActivity(new android.content.Intent(this, HomeActivity.class)
                                .addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP | android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP));
                        finish();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        dialog.setContentView(sheet);
        dialog.show();
        return true;
    }
}
