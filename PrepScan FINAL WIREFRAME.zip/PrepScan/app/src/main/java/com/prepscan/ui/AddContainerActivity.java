package com.prepscan.ui;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.button.MaterialButton;
import com.prepscan.R;

public class AddContainerActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_container);
        setupTopBar(getString(R.string.title_add_container));

        MaterialButton btnAddRemove = findViewById(R.id.btnAddRemoveItems);
        MaterialButton btnPrint = findViewById(R.id.btnPrintQr);

        btnAddRemove.setOnClickListener(v -> {
            Intent i = new Intent(this, AddContentsActivity.class);
            i.putExtra(AddContentsActivity.EXTRA_CONTAINER_ID, "FS001");
            startActivity(i);
        });
        btnPrint.setOnClickListener(v -> startActivity(new Intent(this, PrintLabelActivity.class)));
    }
}
