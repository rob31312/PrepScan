package com.prepscan.ui;

public class ContentRow {
    public final String name;
    public int qty;

    public ContentRow(String name, int qty) {
        this.name = name;
        this.qty = qty;
    }
}
