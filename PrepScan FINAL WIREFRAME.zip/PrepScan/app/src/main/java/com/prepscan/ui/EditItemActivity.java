package com.prepscan.ui;

import android.os.Bundle;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.prepscan.R;

public class EditItemActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);
        setupTopBar(getString(R.string.title_edit_item));
        MaterialButton btnDone = findViewById(R.id.btnDone);
        btnDone.setOnClickListener(v -> { Toast.makeText(this, "Wireframe", Toast.LENGTH_SHORT).show(); finish(); });
    }
}
