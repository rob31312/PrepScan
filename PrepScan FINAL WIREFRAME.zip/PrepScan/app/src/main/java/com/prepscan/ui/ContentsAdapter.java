package com.prepscan.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.prepscan.R;

import java.util.List;

public class ContentsAdapter extends RecyclerView.Adapter<ContentsAdapter.VH> {

    public interface OnUnknownBarcodeFlow {
        void openEditItem();
    }

    private final List<ContentRow> rows;
    private final OnUnknownBarcodeFlow flow;

    public ContentsAdapter(List<ContentRow> rows, OnUnknownBarcodeFlow flow) {
        this.rows = rows;
        this.flow = flow;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_content_item, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        ContentRow row = rows.get(position);
        holder.txtName.setText(row.name);
        holder.txtQty.setText(String.valueOf(row.qty));

        holder.btnMinus.setOnClickListener(v -> {
            if (row.qty > 0) row.qty--;
            holder.txtQty.setText(String.valueOf(row.qty));
        });

        holder.btnPlus.setOnClickListener(v -> {
            row.qty++;
            holder.txtQty.setText(String.valueOf(row.qty));
        });

        holder.txtName.setOnClickListener(v -> flow.openEditItem());
    }

    @Override
    public int getItemCount() {
        return rows.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView txtName;
        TextView txtQty;
        MaterialButton btnMinus;
        MaterialButton btnPlus;

        VH(@NonNull View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txtItemName);
            txtQty = itemView.findViewById(R.id.txtQty);
            btnMinus = itemView.findViewById(R.id.btnMinus);
            btnPlus = itemView.findViewById(R.id.btnPlus);
        }
    }
}
